
alert("Line 4 inside script");